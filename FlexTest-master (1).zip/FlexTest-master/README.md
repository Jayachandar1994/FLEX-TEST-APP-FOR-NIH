# FlexTest
Flexing Test Application developed during CMSC436 class in Spring 2017 
semester with Atif Memon at University of Maryland.

## Instructions
Test Instructions can be found once the app is downloaded.

## Team 09
* Darpan Shah
* Jayachandar Payyavula
* Jon Parker
* Oscar Lomibao Jr.
* Travis Carson
